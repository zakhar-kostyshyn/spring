package com.example.uploadingfiles.repo;

import com.example.uploadingfiles.model.FileEntity;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface FileRepository extends CrudRepository<FileEntity, Long> {

    List<FileEntity> findAll();

}
